import React, { useRef, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import type { RootState } from '../redux/store';
import { clearCart } from '../redux/cartSlice';
import CartItem from './CartItem';
import { X, ShoppingBag } from 'lucide-react';
import { formatCurrency } from '../utils/currency';
import gsap from 'gsap';

interface CartDrawerProps {
    isOpen: boolean;
    onClose: () => void;
}

const CartDrawer: React.FC<CartDrawerProps> = ({ isOpen, onClose }) => {
    const { items, totalAmount, totalQuantity } = useSelector((state: RootState) => state.cart);
    const dispatch = useDispatch();
    const drawerRef = useRef<HTMLDivElement>(null);
    const overlayRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (isOpen) {
            document.body.style.overflow = 'hidden';
            gsap.to(overlayRef.current, { opacity: 1, duration: 0.3, display: 'block' });
            gsap.to(drawerRef.current, { x: 0, duration: 0.4, ease: 'power3.out' });
        } else {
            document.body.style.overflow = '';
            gsap.to(drawerRef.current, { x: '100%', duration: 0.3, ease: 'power3.in' });
            gsap.to(overlayRef.current, { opacity: 0, duration: 0.3, display: 'none' });
        }
    }, [isOpen]);

    return (
        <>
            {/* Overlay */}
            <div
                ref={overlayRef}
                onClick={onClose}
                className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60] hidden opacity-0"
            />

            {/* Drawer */}
            <div
                ref={drawerRef}
                className="fixed top-0 right-0 h-full w-full max-w-md bg-white z-[70] shadow-2xl translate-x-full flex flex-col"
            >
                {/* Header */}
                <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-white sticky top-0">
                    <div className="flex items-center gap-2">
                        <h2 className="text-xl font-bold text-gray-900">Your Cart</h2>
                        <span className="bg-blue-50 text-blue-600 text-xs font-bold px-2 py-0.5 rounded-full">
                            {totalQuantity}
                        </span>
                    </div>
                    <button
                        onClick={onClose}
                        className="p-2 hover:bg-gray-50 rounded-full transition-colors"
                    >
                        <X className="w-6 h-6 text-gray-400" />
                    </button>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto px-6">
                    {items.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-center py-12">
                            <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mb-4">
                                <ShoppingBag className="w-10 h-10 text-gray-300" />
                            </div>
                            <h3 className="text-lg font-bold text-gray-900 mb-1">Your cart is empty</h3>
                            <p className="text-sm text-gray-500 max-w-[200px]">
                                Looks like you haven't added anything to your cart yet.
                            </p>
                            <button
                                onClick={onClose}
                                className="mt-6 text-blue-600 font-bold text-sm hover:underline"
                            >
                                Start Shopping
                            </button>
                        </div>
                    ) : (
                        <div className="divide-y divide-gray-50">
                            {items.map((item) => (
                                <CartItem key={item.id} item={item} />
                            ))}
                        </div>
                    )}
                </div>

                {/* Footer */}
                {items.length > 0 && (
                    <div className="p-6 bg-white border-t border-gray-100 space-y-4">
                        <div className="flex items-center justify-between">
                            <span className="text-gray-500 font-medium">Total Amount</span>
                            <span className="text-2xl font-bold text-gray-900">
                                {formatCurrency(totalAmount)}
                            </span>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                            <button
                                onClick={() => dispatch(clearCart())}
                                className="py-3 px-4 border border-gray-200 text-gray-600 font-bold rounded-xl text-sm hover:bg-gray-50 transition-colors"
                            >
                                Clear Cart
                            </button>
                            <button className="py-3 px-4 bg-blue-600 text-white font-bold rounded-xl text-sm flex items-center justify-center gap-2 hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200">
                                Checkout
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </>
    );
};

export default CartDrawer;
