import { useState } from 'react';
import { Provider } from 'react-redux';
import { store } from './redux/store';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import CartDrawer from './components/CartDrawer';

function App() {
  const [isCartOpen, setIsCartOpen] = useState(false);

  return (
    <Provider store={store}>
      <div className="min-h-screen bg-gray-50 flex flex-col font-sans selection:bg-blue-100 selection:text-blue-600">
        <Navbar onCartClick={() => setIsCartOpen(true)} />

        <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8">
          <Home />
        </main>

        <footer className="bg-white border-t border-gray-100 py-12 mt-20">
          <div className="container mx-auto px-4 text-center">
            <p className="text-gray-400 text-sm font-medium">
              &copy; {new Date().getFullYear()} FakeCart Store. Built with React + Vite + TypeScript.
            </p>
          </div>
        </footer>

        <CartDrawer
          isOpen={isCartOpen}
          onClose={() => setIsCartOpen(false)}
        />
      </div>
    </Provider>
  );
}

export default App;
